java -Xms256m -Xmx512m -Dfile.encoding=UTF-8 -cp target/PET-2.0-jar-with-dependencies.jar pet.frontend.PETMain $@
